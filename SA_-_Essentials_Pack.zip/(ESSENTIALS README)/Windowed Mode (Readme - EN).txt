  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2026
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the "Windowed Mode" folder to the "modloader" folder of your GTA SA, or VC, or III. Or to the game folder, or "scripts."

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/



ALT + Enter  � Toggle window mode
With borders, you can resize the window with the mouse while the game is paused.
 


Version: 2.1
--------------------

Author: ThirteenAG


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

